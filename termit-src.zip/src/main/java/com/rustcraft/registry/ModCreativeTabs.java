package com.rustcraft.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Отдельная вкладка креатива "Терминатор": в ней лежат ВСЕ улучшения. */
public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "rustcraft");

    public static final RegistryObject<CreativeModeTab> TERMINATOR_TAB = TABS.register("terminator",
            () -> CreativeModeTab.builder()
                    .title(Component.literal("Терминатор"))                                  // название вкладки
                    .icon(() -> new ItemStack(ModItems.CHIPS.get(2).get()))                   // значок: чип «Зрение: максимальный»
                    .displayItems((params, output) ->                                         // что лежит внутри
                            ModItems.CHIPS.forEach(chip -> output.accept(chip.get())))
                    .build());
}
