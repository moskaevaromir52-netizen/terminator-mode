package com.rustcraft.client;

import com.mojang.blaze3d.shaders.FogShape;
import com.rustcraft.common.ClientState;
import com.rustcraft.net.ActionPacket;
import com.rustcraft.net.NetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.gui.Font;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * Клиент: клавиша P, туман/затемнение (Зрение), линия и подсветка игроков (Сканер).
 * Индекс в массивах ниже = уровень системы (0 повреждён, 1 средний, 2 максимальный).
 */
@Mod.EventBusSubscriber(modid = "rustcraft", value = Dist.CLIENT)
public class ClientEvents {
    // Сканер: как часто бежит линия / подсвечиваются игроки, на сколько тиков, и радиус.
    private static final int[] LINE_INTERVAL = {100, 60, 40};
    private static final int[] HL_INTERVAL = {100, 60, 20};
    private static final int[] HL_DURATION = {40, 40, 30};
    private static final double[] RADIUS = {16.0, 32.0, 48.0};
    private static final int LINE_SWEEP_TICKS = 20;

    private static int tick = 0;
    private static int lineStart = -1000;
    /** Какой пост-шейдер сейчас включён (null = никакого). */
    private static ResourceLocation shaderLoaded = null;
    private static final ResourceLocation SHADER_DAMAGED = new ResourceLocation("shaders/post/desaturate.json");   // чёрно-белый экран
    private static final ResourceLocation SHADER_RED = new ResourceLocation("rustcraft", "shaders/post/red_vision.json"); // красное ночное зрение
    private static LocalPlayer lastPlayer = null;
    /** id игрока -> тик, когда подсветку надо выключить. */
    private static final Map<Integer, Integer> highlighted = new HashMap<>();

    // ---------- Клавиша P ----------
    private static void handleKey(Minecraft mc) {
        while (KeyBindings.TERMINATOR_KEY.consumeClick()) {
            if (mc.player == null || mc.screen != null) continue;   // только в игре, не поверх других окон
            if (!ClientState.active) {
                // Ещё человек -> P делает тебя терминатором (навсегда)
                NetworkHandler.CHANNEL.sendToServer(new ActionPacket(ActionPacket.ACTIVATE, 0));
            } else {
                // Уже терминатор -> P открывает слоты улучшений
                mc.setScreen(new UpgradeScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        handleKey(mc);

        // Нет мира — всё сбрасываем
        if (mc.player == null || mc.level == null) {
            shaderLoaded = null;
            highlighted.clear();
            lastPlayer = null;
            return;
        }
        if (mc.player != lastPlayer) { // новый игрок (респавн/смена мира)
            lastPlayer = mc.player;
            shaderLoaded = null;
            highlighted.clear();
        }
        tick++;

        // Зрение: "повреждён" = чёрно-белый экран, "максимальный" (ночное зрение) = красный экран
        ResourceLocation wantShader = !ClientState.active ? null
                : ClientState.vision == 0 ? SHADER_DAMAGED
                : ClientState.vision == 2 ? SHADER_RED
                : null;
        if (!Objects.equals(wantShader, shaderLoaded)) {
            if (wantShader == null) mc.gameRenderer.shutdownEffect();
            else mc.gameRenderer.loadEffect(wantShader);
            shaderLoaded = wantShader;
        }

        if (ClientState.active) {
            int s = ClientState.scanner;
            if (tick % LINE_INTERVAL[s] == 0) lineStart = tick;          // запускаем бегущую линию
            if (tick % HL_INTERVAL[s] == 0) {                            // подсвечиваем ближних игроков
                double r2 = RADIUS[s] * RADIUS[s];
                for (Entity other : mc.level.entitiesForRendering()) { // ВСЕ сущности: мобы, животные, игроки, предметы...
                    if (other == mc.player) continue;
                    if (mc.player.distanceToSqr(other) <= r2) {
                        highlighted.put(other.getId(), tick + HL_DURATION[s]);
                    }
                }
            }
        } else if (!highlighted.isEmpty()) {                             // перестали быть терминатором — гасим подсветку
            for (Integer id : highlighted.keySet()) setGlow(mc, id, false);
            highlighted.clear();
        }

        // Выключаем подсветку, когда вышло время
        Iterator<Map.Entry<Integer, Integer>> it = highlighted.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> en = it.next();
            if (en.getValue() <= tick) {
                setGlow(mc, en.getKey(), false);
                it.remove();
            } else {
                setGlow(mc, en.getKey(), true);
            }
        }
    }

    private static void setGlow(Minecraft mc, int id, boolean glow) {
        if (mc.level == null) return;
        Entity ent = mc.level.getEntity(id);
        if (ent == null) return;
        ent.setGlowingTag(glow);
        forceGlowFlag(ent, glow); // на клиенте setGlowingTag сам флаг не меняет, поэтому ставим его напрямую
    }

    private static Method setSharedFlag;
    private static boolean setSharedFlagResolved = false;

    /** Entity.setSharedFlag(6, glow) — бит 6 = "светится". Метод protected, берём через рефлексию (SRG-имя m_20115_). */
    private static void forceGlowFlag(Entity ent, boolean glow) {
        if (!setSharedFlagResolved) {
            setSharedFlagResolved = true;
            try {
                setSharedFlag = ObfuscationReflectionHelper.findMethod(Entity.class, "m_20115_", int.class, boolean.class);
            } catch (Throwable t) {
                setSharedFlag = null; // не нашли — остаётся только обычный setGlowingTag
            }
        }
        if (setSharedFlag == null) return;
        try {
            setSharedFlag.invoke(ent, 6, glow);
        } catch (Throwable ignored) {
        }
    }

    // ---------- Зрение: туман и затемнение (уровни 0 и 1) ----------
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        float far = ClientState.vision == 0 ? 6.0f : 24.0f;
        e.setNearPlaneDistance(0f);
        e.setFarPlaneDistance(far);
        e.setFogShape(FogShape.SPHERE);
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        e.setRed(0f);
        e.setGreen(0f);
        e.setBlue(0f);
    }

    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        GuiGraphics g = e.getGuiGraphics();
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        g.fill(0, 0, w, h, 0x38000000);
        if (ClientState.vision == 0) oldCamera(g, w, h); // самое плохое зрение = старая плохая камера
    }

    // ---------- Зрение "повреждён": эффект старой камеры ----------
    private static final java.util.Random FX = new java.util.Random();

    /** Чёрно-белый экран (шейдер) + сепия, зерно, строки развёртки, мерцание, виньетка, полоса помех и значок REC. */
    private static void oldCamera(GuiGraphics g, int w, int h) {
        // 1) тёплый сепия-оттенок
        g.fill(0, 0, w, h, 0x30705028);

        // 2) мерцание яркости (каждый кадр чуть по-разному) + редкая яркая вспышка
        int flicker = FX.nextInt(26);
        g.fill(0, 0, w, h, (flicker << 24));
        if (FX.nextInt(45) == 0) g.fill(0, 0, w, h, 0x28FFFFFF);

        // 3) строки развёртки (тонкие тёмные линии через одну)
        for (int y = 0; y < h; y += 2) g.fill(0, y, w, y + 1, 0x28000000);

        // 4) зерно: случайные светлые и тёмные точки, каждый кадр новые
        int dots = w * h / 450;
        for (int i = 0; i < dots; i++) {
            int x = FX.nextInt(w), y = FX.nextInt(h);
            int a = 0x30 + FX.nextInt(0x60);
            int c = FX.nextBoolean() ? 0xFFFFFF : 0x000000;
            g.fill(x, y, x + 1 + FX.nextInt(2), y + 1, (a << 24) | c);
        }

        // 5) полоса помех, которая время от времени ползёт сверху вниз (как плохая плёнка)
        int cycle = tick % 160;
        if (cycle < 30) {
            int by = (int) (cycle / 30.0 * (h + 20)) - 20;
            g.fill(0, by, w, by + 8, 0x22FFFFFF);
            g.fill(0, by + 8, w, by + 10, 0x30000000);
        }

        // 6) виньетка: затемнение по краям кольцами
        int steps = 14;
        int sx = Math.max(2, w / 48), sy = Math.max(2, h / 48);
        for (int i = 0; i < steps; i++) {
            double k = 1.0 - i / (double) steps;
            int col = ((int) (170 * k * k)) << 24;
            int x0 = i * sx, y0 = i * sy, x1 = w - i * sx, y1 = h - i * sy;
            if (x1 <= x0 || y1 <= y0) break;
            g.fill(x0, y0, x1, y0 + sy, col);
            g.fill(x0, y1 - sy, x1, y1, col);
            g.fill(x0, y0 + sy, x0 + sx, y1 - sy, col);
            g.fill(x1 - sx, y0 + sy, x1, y1 - sy, col);
        }

        // 7) значок записи REC в углу (мигает раз в секунду)
        if ((tick / 20) % 2 == 0) {
            g.fill(10, 10, 18, 18, 0xFFE02020);
            g.drawString(Minecraft.getInstance().font, "REC", 22, 10, 0xFFE02020, false);
        }
    }

    /** Лёгкая тряска кадра (только наклон, прицел не сбивается). */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles e) {
        if (!ClientState.active || ClientState.vision != 0) return;
        float shake = (float) (Math.sin((tick + e.getPartialTick()) * 0.9) * 0.35 + (FX.nextFloat() - 0.5f) * 0.4f);
        e.setRoll(e.getRoll() + shake);
    }

    // ---------- Сканер: рамки с подписями вокруг целей (как в фильме) ----------
    private static final Matrix4f projView = new Matrix4f();
    private static Vec3 camPos = Vec3.ZERO;
    private static boolean projValid = false;

    /** Запоминаем матрицы камеры, чтобы потом перевести координаты существа из мира в координаты экрана. */
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!ClientState.active) {
            projValid = false;
            return;
        }
        projView.set(e.getProjectionMatrix()).mul(e.getPoseStack().last().pose());
        camPos = e.getCamera().getPosition();
        projValid = true;
    }

    /** Рамка-уголки вокруг каждого подсвеченного ЖИВОГО существа + имя, расстояние и здоровье. */
    @SubscribeEvent
    public static void onGuiTargets(RenderGuiEvent.Post e) {
        if (!ClientState.active || !projValid || highlighted.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        GuiGraphics g = e.getGuiGraphics();
        Font font = mc.font;
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        float pt = e.getPartialTick();
        boolean glitch = ClientState.vision == 0; // при повреждённом зрении рамки дёргаются, а подписи рассыпаются

        for (Integer id : highlighted.keySet()) {
            Entity ent = mc.level.getEntity(id);
            if (!(ent instanceof LivingEntity le)) continue;

            // положение с учётом сглаживания между тиками
            double ox = Mth.lerp(pt, ent.xo, ent.getX()) - ent.getX();
            double oy = Mth.lerp(pt, ent.yo, ent.getY()) - ent.getY();
            double oz = Mth.lerp(pt, ent.zo, ent.getZ()) - ent.getZ();
            AABB box = ent.getBoundingBox().move(ox, oy, oz);

            // проецируем 8 углов коробки на экран
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean visible = true;
            for (int i = 0; i < 8; i++) {
                double cx = (i & 1) == 0 ? box.minX : box.maxX;
                double cy = (i & 2) == 0 ? box.minY : box.maxY;
                double cz = (i & 4) == 0 ? box.minZ : box.maxZ;
                Vector4f v = new Vector4f((float) (cx - camPos.x), (float) (cy - camPos.y), (float) (cz - camPos.z), 1f);
                projView.transform(v);
                if (v.w <= 0.05f) { visible = false; break; }   // позади камеры
                float sx = (v.x / v.w * 0.5f + 0.5f) * w;
                float sy = (1f - (v.y / v.w * 0.5f + 0.5f)) * h;
                minX = Math.min(minX, sx); maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
            }
            if (!visible || maxX < 0 || minX > w || maxY < 0 || minY > h) continue;

            int x0 = (int) minX, y0 = (int) minY, x1 = (int) maxX, y1 = (int) maxY;
            if (x1 - x0 < 8) { int c = (x0 + x1) / 2; x0 = c - 4; x1 = c + 4; }
            if (y1 - y0 < 8) { int c = (y0 + y1) / 2; y0 = c - 4; y1 = c + 4; }
            if (glitch && FX.nextInt(3) == 0) {               // дёрганье рамки
                int jx = FX.nextInt(5) - 2, jy = FX.nextInt(5) - 2;
                x0 += jx; x1 += jx; y0 += jy; y1 += jy;
            }

            int col = (ent instanceof Enemy) ? 0xFFFF3030 : 0xFFE89090;   // враги ярко-красные
            int lx = Math.max(3, Math.min(12, (x1 - x0) / 3));
            int ly = Math.max(3, Math.min(12, (y1 - y0) / 3));
            g.fill(x0, y0, x0 + lx, y0 + 1, col);  g.fill(x0, y0, x0 + 1, y0 + ly, col);      // левый верх
            g.fill(x1 - lx, y0, x1, y0 + 1, col);  g.fill(x1 - 1, y0, x1, y0 + ly, col);      // правый верх
            g.fill(x0, y1 - 1, x0 + lx, y1, col);  g.fill(x0, y1 - ly, x0 + 1, y1, col);      // левый низ
            g.fill(x1 - lx, y1 - 1, x1, y1, col);  g.fill(x1 - 1, y1 - ly, x1, y1, col);      // правый низ

            // подписи: имя, затем расстояние и здоровье
            String name = ent.getName().getString().toUpperCase(Locale.ROOT);
            String info = Math.round(mc.player.distanceTo(ent)) + " m   HP " + Math.round(le.getHealth());
            if (glitch) { name = glitchText(name); info = glitchText(info); }
            int ty = (y0 > 24) ? y0 - 20 : y1 + 3;
            g.drawString(font, name, x0, ty, col, false);
            g.drawString(font, info, x0, ty + 10, col, false);
        }
    }

    /** Случайно портит часть символов (для зрения "повреждён"). */
    private static String glitchText(String s) {
        if (FX.nextInt(4) != 0) return s;                      // чаще текст целый, иногда рассыпается
        StringBuilder sb = new StringBuilder(s);
        String junk = "#%&@?/*!";
        for (int i = 0; i < sb.length(); i++) {
            if (FX.nextInt(5) == 0) sb.setCharAt(i, junk.charAt(FX.nextInt(junk.length())));
        }
        return sb.toString();
    }

    // ---------- Сканер: бегущая линия сверху вниз ----------
    @SubscribeEvent
    public static void onGuiPost(RenderGuiEvent.Post e) {
        if (!ClientState.active) return;
        float t = (tick - lineStart) + e.getPartialTick();
        if (t < 0 || t >= LINE_SWEEP_TICKS) return;
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        int y = (int) (t / LINE_SWEEP_TICKS * h);
        GuiGraphics g = e.getGuiGraphics();
        g.fill(0, y - 10, w, y - 5, 0x18FFFFFF);
        g.fill(0, y - 5, w, y - 2, 0x40FFFFFF);
        g.fill(0, y - 2, w, y + 2, 0xFFFFFFFF);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.reset();
        highlighted.clear();
        shaderLoaded = null;
    }
}
