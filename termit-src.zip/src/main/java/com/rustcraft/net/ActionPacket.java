package com.rustcraft.net;

import com.rustcraft.common.ServerEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Клиент -> сервер: действие игрока с клавиши P / из экрана улучшений.
 *   ACTIVATE    — стать терминатором (необратимо, обратного действия нет);
 *   CYCLE       — переключить уровень системы (номер слота в поле system).
 */
public class ActionPacket {
    public static final int ACTIVATE = 0;
    public static final int CYCLE = 1;

    public final int type;
    public final int system;

    public ActionPacket(int type, int system) {
        this.type = type;
        this.system = system;
    }

    public static void encode(ActionPacket p, FriendlyByteBuf buf) {
        buf.writeByte(p.type);
        buf.writeByte(p.system);
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        return new ActionPacket(buf.readByte(), buf.readByte());
    }

    public static void handle(ActionPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (p.type == ACTIVATE) {
                ServerEvents.activate(player);
            } else if (p.type == CYCLE && p.system >= 0 && p.system < 3) { // проверка: сервер не верит клиенту на слово
                ServerEvents.cycle(player, p.system);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
