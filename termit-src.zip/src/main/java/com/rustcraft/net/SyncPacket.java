package com.rustcraft.net;

import com.rustcraft.common.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: "ты терминатор? и какие уровни у систем". */
public class SyncPacket {
    public final boolean active;
    public final int vision, memory, scanner;

    public SyncPacket(boolean active, int vision, int memory, int scanner) {
        this.active = active;
        this.vision = vision;
        this.memory = memory;
        this.scanner = scanner;
    }

    public static void encode(SyncPacket p, FriendlyByteBuf buf) {
        buf.writeBoolean(p.active);
        buf.writeByte(p.vision);
        buf.writeByte(p.memory);
        buf.writeByte(p.scanner);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        return new SyncPacket(buf.readBoolean(), buf.readByte(), buf.readByte(), buf.readByte());
    }

    public static void handle(SyncPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ClientState.active = p.active;
            ClientState.vision = p.vision;
            ClientState.memory = p.memory;
            ClientState.scanner = p.scanner;
        });
        ctx.get().setPacketHandled(true);
    }
}
